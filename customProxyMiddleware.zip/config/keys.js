module.exports = {
  responsysKeys: () => {
    return {
      users: {
        B2CLG: {
          user: "grendene.occ.lojagrendene",
          password: "V1aK11Cvpary@",
          folderName: "Loja_Grendene",
          host: "https://gbm1rs4-api.responsys.ocs.oraclecloud.com/rest/api/v1.3",
        },
        B2CGNZaxy: {
          user: "grendene.occ",
          password: "techRM2020!",
          folderName: "Zaxy",
          host: "https://gk71qiq-api.responsys.ocs.oraclecloud.com/rest/api/v1.3",
        },
        B2CGNRider: {
          user: "grendene_occ_rider",
          password: "techRM2020!",
          folderName: "Rider",
          host: "https://ghd1qk2-api.responsys.ocs.oraclecloud.com/rest/api/v1.3",
        },
        B2CMN: {
          user: "grendene.occ.melissabr",
          password: "techRM2020!",
          folderName: "Melissa",
          host: "https://geg1qsf-api.responsys.ocs.oraclecloud.com/rest/api/v1.3",
        },
        B2CMIUS: {
          user: "grendene_occ",
          password: "techRM2020!",
          folderName: "Melissa",
          host: "https://rest001.rsys9.net/rest/api/v1.3",
        },
        B2CGNGrendeneKids: {
          user: "grendene_occ_grendenekids",
          password: "techRM2020!",
          folderName: "Grendene_Kids",
          host: "https://gcj1qke-api.responsys.ocs.oraclecloud.com/rest/api/v1.3",
        },
        B2CGNIpanema: {
          user: "grendene_occ_ipanema",
          password: "techRM2020!",
          folderName: "Ipanema",
          host: "https://gb91qk1-api.responsys.ocs.oraclecloud.com/rest/api/v1.3",
        },
        B2CGNGrendha: {
          user: "grendene.occ.grendha",
          password: "techRM2020!",
          folderName: "Grendha",
          host: "https://g991qjz-api.responsys.ocs.oraclecloud.com/rest/api/v1.3",
        },
        B2CGNCartago: {
          user: "grendene_occ_cartago",
          password: "techRM2020!",
          folderName: "Cartago",
          host: "https://gjb1qk0-api.responsys.ocs.oraclecloud.com/rest/api/v1.3",
        },
      },
    };
  },
};
